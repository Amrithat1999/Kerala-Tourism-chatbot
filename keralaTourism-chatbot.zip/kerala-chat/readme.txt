run
	main.py

dataset
	data.txt


eg:running 
	പാക്കേജുകൾ കൊച്ചി
